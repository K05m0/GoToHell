using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName ="So Values/New int Value",fileName ="New int Value")]

public class playerhealth :ScriptableObject
{
    public int value = 3;
}
